var a00145 =
[
    [ "rx_buf", "a00145.html#ab5c77995614a78b4a7baf6f5ab59bb5c", null ],
    [ "rx_buf_size", "a00145.html#a42c5f8c78ee123d84c7de5da43f703e0", null ],
    [ "tx_buf", "a00145.html#a1073bbd41b6d0ddc55e7ec432cf517dd", null ],
    [ "tx_buf_size", "a00145.html#a8a0ff8a830eadfc972a4d44e1340e392", null ]
];