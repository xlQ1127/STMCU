var a00235 =
[
    [ "init_len", "a00235.html#a7722e94b0c079f7571a0607a13d46bde", null ],
    [ "init_offs", "a00235.html#aa24ec5661c2ba830f906201285ca941c", null ],
    [ "max_len", "a00235.html#a5cc60017697406f2f2624e0b15dad294", null ],
    [ "p_attr_md", "a00235.html#afc04d5311dcd31df52f7d9aac7c05ab1", null ],
    [ "p_uuid", "a00235.html#a87b18c161a362b54bd349aebd2a45c85", null ],
    [ "p_value", "a00235.html#abf26555ce0ad9b481c3f638f89dc329a", null ]
];