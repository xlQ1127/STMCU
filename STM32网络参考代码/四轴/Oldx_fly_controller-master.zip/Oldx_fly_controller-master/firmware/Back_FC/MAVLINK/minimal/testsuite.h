

/** @file
 *	@brief MAVLink comm protocol testsuite generated from minimal.xml
 *	@see http://qgroundcontrol.org/mavlink/
 */
#ifndef MINIMAL_TESTSUITE_H
#define MINIMAL_TESTSUITE_H

#include "minimal.h"

#endif // MINIMAL_TESTSUITE_H


