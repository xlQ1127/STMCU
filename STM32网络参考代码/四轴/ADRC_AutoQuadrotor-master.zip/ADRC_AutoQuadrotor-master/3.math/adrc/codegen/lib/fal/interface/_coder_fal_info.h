/* 
 * File: _coder_fal_info.h 
 *  
 * MATLAB Coder version            : 2.6 
 * C/C++ source code generated on  : 28-Jun-2017 11:24:40 
 */

#ifndef ___CODER_FAL_INFO_H__
#define ___CODER_FAL_INFO_H__
/* Include files */
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"


/* Function Declarations */
extern const mxArray *emlrtMexFcnResolvedFunctionsInfo(void);

#endif
/* 
 * File trailer for _coder_fal_info.h 
 *  
 * [EOF] 
 */
