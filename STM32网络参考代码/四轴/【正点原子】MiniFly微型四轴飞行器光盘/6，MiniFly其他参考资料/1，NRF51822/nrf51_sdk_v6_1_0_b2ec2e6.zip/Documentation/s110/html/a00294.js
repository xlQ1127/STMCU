var a00294 =
[
    [ "location_list", "a00294.html#afd78c23388141f9344bc5e6ffcaedb75", null ],
    [ "opcode", "a00294.html#a155379662bc1d70f1006fdb6cb3993cb", null ],
    [ "status", "a00294.html#a2879f0a89583e6148c81d3b8127fe520", null ]
];