var a00184 =
[
    [ "conn_sup_timeout", "a00184.html#ab644e629af7eb4915b0f3a93f682f7ae", null ],
    [ "max_conn_interval", "a00184.html#abd7a6e16a723de1d779afadae3f3113e", null ],
    [ "min_conn_interval", "a00184.html#a4d1975f7d25263004c405e0321fbae34", null ],
    [ "slave_latency", "a00184.html#aa5caf55715aaac33f56cc996f91a92cc", null ]
];