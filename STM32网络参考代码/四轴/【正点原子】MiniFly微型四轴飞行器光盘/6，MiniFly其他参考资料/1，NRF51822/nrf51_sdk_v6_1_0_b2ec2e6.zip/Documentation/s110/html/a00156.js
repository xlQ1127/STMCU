var a00156 =
[
    [ "battery_level_char_attr_md", "a00156.html#aba436d52b264fb93a74de510a9e7ef07", null ],
    [ "battery_level_report_read_perm", "a00156.html#a07135d9b12640710f520ef87d7a4f1be", null ],
    [ "evt_handler", "a00156.html#a84932ecefd721efa23840b01ca3ce7eb", null ],
    [ "initial_batt_level", "a00156.html#a22993ab4d63fdbd764624856605d1b7f", null ],
    [ "p_report_ref", "a00156.html#afcbdf538aff06891b6f0057015b5c6e0", null ],
    [ "support_notification", "a00156.html#ad4f3272ae66ece4ee5a4b8c3ff7fba88", null ]
];