#ifndef DEV_NVIC_H
#define DEV_NVIC_H

#include "stm32f4xx.h"
class _NVIC
{
	 private:
	 public:	
	 static void Configuration(void);
	
};

extern _NVIC Nvic;

#endif