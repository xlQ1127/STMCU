var a00247 =
[
    [ "handle", "a00247.html#a1a0552b266c588f67d3a6abc712bbfd6", null ],
    [ "offset", "a00247.html#a07033f6e0e63974b67627ae84bc12fc9", null ],
    [ "p_data", "a00247.html#a68325153be760c7742d1bec69da625cf", null ],
    [ "p_len", "a00247.html#a8b0b2dadb3128b0838c71235661f8174", null ],
    [ "type", "a00247.html#a2971c791821bea067f3bc2bbc35b9193", null ]
];