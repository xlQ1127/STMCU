#ifndef DEV_PORT_H
#define DEV_PORT_H
#include "includes.h"
class _PORT
{
	 private:
	 public:	
	 static void Configuration(void);
	
};

extern _PORT Port;

#endif