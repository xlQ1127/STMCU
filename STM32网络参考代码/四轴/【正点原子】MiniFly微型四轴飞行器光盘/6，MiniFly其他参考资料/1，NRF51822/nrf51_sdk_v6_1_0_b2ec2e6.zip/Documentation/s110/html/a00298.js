var a00298 =
[
    [ "report_id", "a00298.html#a4db26fdff00f44138f9f684ff1dfd149", null ],
    [ "report_type", "a00298.html#a765872684206db6d91ad6de596599434", null ]
];