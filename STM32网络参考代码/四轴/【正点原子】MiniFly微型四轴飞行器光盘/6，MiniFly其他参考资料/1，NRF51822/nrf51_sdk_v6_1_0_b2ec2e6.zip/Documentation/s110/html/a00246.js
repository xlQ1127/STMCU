var a00246 =
[
    [ "context", "a00246.html#a1728a17f5c77bff7285e29c1a8afe6e8", null ],
    [ "data", "a00246.html#abe4bd839db7c40829ccdbff3d1f79a57", null ],
    [ "handle", "a00246.html#ae0637f8a8c322380f80f113edc931751", null ],
    [ "len", "a00246.html#a56b5ec3ad2054c52588721d6273eb109", null ],
    [ "offset", "a00246.html#afc84657816fd23a1e7c5f4b0e848e69d", null ],
    [ "op", "a00246.html#a4e27117bb9e805b03a2c198b0684c621", null ]
];