#ifndef UAV_INIT_H
#define UAV_INIT_H

#include "includes.h"
class _UAV
{
	 private:
	 public:	
	 static void Init(void);
	
};

extern _UAV Uav;

#endif