/* 
 * File: _coder_AttitudeEKF_info.h 
 *  
 * MATLAB Coder version            : 2.6 
 * C/C++ source code generated on  : 23-Apr-2017 01:32:45 
 */

#ifndef ___CODER_ATTITUDEEKF_INFO_H__
#define ___CODER_ATTITUDEEKF_INFO_H__
/* Include files */
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"


/* Function Declarations */
extern const mxArray *emlrtMexFcnResolvedFunctionsInfo(void);

#endif
/* 
 * File trailer for _coder_AttitudeEKF_info.h 
 *  
 * [EOF] 
 */
