var a00293 =
[
    [ "encoded_ctrl_rsp", "a00293.html#adf17b1a0cd599ca5bd71dba42e318e06", null ],
    [ "len", "a00293.html#afb2e07899dd914805f45b9da0694e0af", null ],
    [ "status", "a00293.html#a978ed1543a79395ebdefc4f92233dfb7", null ]
];