/* 
 * File: _coder_nav_h_ekf_info.h 
 *  
 * MATLAB Coder version            : 2.6 
 * C/C++ source code generated on  : 03-Jul-2017 11:01:12 
 */

#ifndef ___CODER_NAV_H_EKF_INFO_H__
#define ___CODER_NAV_H_EKF_INFO_H__
/* Include files */
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"


/* Function Declarations */
extern const mxArray *emlrtMexFcnResolvedFunctionsInfo(void);

#endif
/* 
 * File trailer for _coder_nav_h_ekf_info.h 
 *  
 * [EOF] 
 */
