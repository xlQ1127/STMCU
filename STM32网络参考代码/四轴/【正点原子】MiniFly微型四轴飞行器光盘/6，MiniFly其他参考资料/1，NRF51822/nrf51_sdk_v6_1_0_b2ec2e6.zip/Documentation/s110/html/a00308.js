var a00308 =
[
    [ "evt_type", "a00308.html#ac7e76a07c099aed4eb9d8180a15368d8", null ],
    [ "packet", "a00308.html#a005a67172eb3d6a4645d536db7fbb98f", null ],
    [ "packet_length", "a00308.html#ac31d16ccc1a5fc4bd8852c58d710f821", null ]
];