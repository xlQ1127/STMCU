var a00148 =
[
    [ "baud_rate", "a00148.html#af3f1e2f02e0c2d6fdfbc09fc335a373a", null ],
    [ "cts_pin_no", "a00148.html#a3db286645aa6ca3d00b4050837dfac81", null ],
    [ "rts_pin_no", "a00148.html#a7bd1bcc691294dfa173105c79e926318", null ],
    [ "rx_pin_no", "a00148.html#a1bb6d6aa16efc7c4d2caee51d8058213", null ],
    [ "tx_pin_no", "a00148.html#aa13645e8ecb6cb1970dba53fabe08b40", null ],
    [ "use_parity", "a00148.html#a52a6d334142f15d9c5ab04c988a40b91", null ]
];