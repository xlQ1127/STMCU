/*
 * File: nav_h_ekf_terminate.c
 *
 * MATLAB Coder version            : 2.6
 * C/C++ source code generated on  : 03-Jul-2017 02:29:18
 */

/* Include files */
#include "rt_nonfinite.h"
#include "nav_h_ekf.h"
#include "nav_h_ekf_terminate.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void nav_h_ekf_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for nav_h_ekf_terminate.c
 *
 * [EOF]
 */
