var a00116 =
[
    [ "Advertising Data Encoder", "a00118.html", null ],
    [ "Debug Assert Handler", "a00119.html", null ],
    [ "BLE Device Manager", "a00126.html", [
      [ "Initialization", "a00126.html#lib_device_manaegerit", [
        [ "Associated Events", "a00126.html#lib_device_manager_init_evt", null ],
        [ "Associated Configuration Parameters", "a00126.html#lib_device_manager_init_cnfg_param", null ]
      ] ],
      [ "Registration", "a00126.html#lib_device_manager_register", [
        [ "Associated Events", "a00126.html#lib_cnxn_register_evt", null ],
        [ "Associated Configuration Parameters", "a00126.html#lib_cnxn_register_cnfg_param", null ]
      ] ]
    ] ],
    [ "Connection Parameters Negotiation", "a00120.html", [
      [ "Overview", "a00120.html#Overview", null ],
      [ "Initialization and Set-up", "a00120.html#lib_ble_conn_params_init", null ],
      [ "Shutdown", "a00120.html#lib_ble_conn_params_stop", null ],
      [ "Change/Update Connection Parameters Negotiated", "a00120.html#lib_ble_conn_params_change_conn_params", null ]
    ] ],
    [ "DTM - Direct Test Mode", "a00121.html", null ],
    [ "Error Log", "a00122.html", null ],
    [ "Record Access Control Point", "a00123.html", null ],
    [ "Radio Notification Event Handler", "a00124.html", null ],
    [ "Sensor Data Simulator", "a00125.html", null ]
];