var a00117 =
[
    [ "Alert Notification Service Client", "a00127.html", null ],
    [ "Battery Service", "a00128.html", null ],
    [ "Blood Pressure Service", "a00129.html", null ],
    [ "Cycling Speed and Cadence Service", "a00130.html", null ],
    [ "Device Information Service", "a00131.html", null ],
    [ "Glucose Service", "a00132.html", [
      [ "Glucose Service", "a00132.html#section_glucose_service", null ],
      [ "Glucose Service Database", "a00132.html#section_glucose_service_db", null ]
    ] ],
    [ "Health Thermometer Service", "a00133.html", null ],
    [ "Heart Rate Service", "a00134.html", null ],
    [ "Human Interface Device Service", "a00135.html", null ],
    [ "Human Immediate Alert Service", "a00136.html", null ],
    [ "Human Immediate Alert Service Client", "a00137.html", null ],
    [ "Link Loss Service", "a00138.html", null ],
    [ "Running Speed and Cadence Service", "a00139.html", null ],
    [ "TX Power Service", "a00140.html", null ]
];