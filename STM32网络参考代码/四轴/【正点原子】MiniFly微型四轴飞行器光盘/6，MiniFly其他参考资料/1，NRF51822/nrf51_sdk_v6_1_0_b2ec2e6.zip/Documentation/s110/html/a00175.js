var a00175 =
[
    [ "manufacturer_id", "a00175.html#ae1f58152dab08532bc52edd976c2f51c", null ],
    [ "organizationally_unique_id", "a00175.html#a452099e99c407f16e24299e57e53af46", null ]
];