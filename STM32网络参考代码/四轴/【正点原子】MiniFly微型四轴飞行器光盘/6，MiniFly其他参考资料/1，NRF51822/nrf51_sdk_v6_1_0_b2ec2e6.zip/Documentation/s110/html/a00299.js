var a00299 =
[
    [ "read_perm", "a00299.html#ac08fb7f662817574a3792609f0d92637", null ],
    [ "write_perm", "a00299.html#aca8d641cf8e5b5811aa2a2c68035c395", null ]
];