var a00269 =
[
    [ "bsl_handles", "a00269.html#a0a32b7e1cf6a5f95cdeeb6eaa8f6f6ba", null ],
    [ "conn_handle", "a00269.html#a3d918e6a8f1da592ea67134cb9c9fec9", null ],
    [ "evt_handler", "a00269.html#abd7c3e92fc72df788563a53bd0f4ce2d", null ],
    [ "hrcp_handles", "a00269.html#a1c58eabf826182923b1f2ed209f8dc0e", null ],
    [ "hrm_handles", "a00269.html#a77fcb24345f20bd721cf5a2820749875", null ],
    [ "is_expended_energy_supported", "a00269.html#ac2328b5880df56c0afca889faaac0cab", null ],
    [ "is_sensor_contact_detected", "a00269.html#a63f11f789786cf4e44bae53c8f63c55e", null ],
    [ "is_sensor_contact_supported", "a00269.html#aa373c36f6b186c6d6a2846535cf431e3", null ],
    [ "rr_interval", "a00269.html#aaae77371d110359230bee5c06d9f1e4f", null ],
    [ "rr_interval_count", "a00269.html#a9cf8168d7866d6530c9763a0953bb8d2", null ],
    [ "service_handle", "a00269.html#adaa286c0fe8805c891b2b4160ca4ac0b", null ]
];