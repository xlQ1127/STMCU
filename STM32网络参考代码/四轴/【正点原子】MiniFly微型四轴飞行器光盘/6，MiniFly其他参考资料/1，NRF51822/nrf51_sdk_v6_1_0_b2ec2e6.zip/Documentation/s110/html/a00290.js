var a00290 =
[
    [ "inst_cadence", "a00290.html#ae0184379a72ca968be31624693859296", null ],
    [ "inst_speed", "a00290.html#a2c67fcdf6c045252f8f2c19410ce93ce", null ],
    [ "inst_stride_length", "a00290.html#a80d5e5ebfb6d4e01cf5a3716af83bf6f", null ],
    [ "is_inst_stride_len_present", "a00290.html#ae051edb606a9de9cebc7ab7a6eef2ae0", null ],
    [ "is_running", "a00290.html#a1b8f312b31cdc3a4b06f092ce7e2bd8e", null ],
    [ "is_total_distance_present", "a00290.html#abd1ef1791fd6291c82c5b2f5d9bd289f", null ],
    [ "total_distance", "a00290.html#a446576bd70deec710453a5e09ff1f7c2", null ]
];