var a00004 =
[
    [ "BLE Peripheral", "a00082.html", "a00082" ],
    [ "Bootloader/DFU - SoftDevice update support", "a00056.html", "a00056" ],
    [ "Direct Test Mode", "a00054.html", [
      [ "Direct Test Mode", "a00054.html#project_dtm_intro", null ],
      [ "BLE DTM module interface", "a00054.html#ble_sdk_dtm_lib_interface", null ],
      [ "Vendor Specific Packet Payload", "a00054.html#ble_sdk_dtm_proprietary", null ],
      [ "The DTM to Serial adaptation layer", "a00054.html#ble_sdk_dtm_serial2w", null ],
      [ "Running DTM tests", "a00054.html#ble_sdk_dtm_testing", null ]
    ] ],
    [ "Hardware Peripheral Examples", "a00023.html", "a00023" ],
    [ "Nordic proprietary protocols", "a00115.html", "a00115" ]
];