var a00237 =
[
    [ "char_ext_props", "a00237.html#ac5e56544775870bc0dfcccbfe49546c5", null ],
    [ "char_props", "a00237.html#a3d9381741f1a0b9e3ca5e2a5ddeb6877", null ],
    [ "char_user_desc_max_size", "a00237.html#a5916d5b2468348a72e9dcbdfc8d09404", null ],
    [ "char_user_desc_size", "a00237.html#a1fdf0123a1e5ae6591be0e16879c7bf4", null ],
    [ "p_cccd_md", "a00237.html#a86233448bf572b753bb23acc21836887", null ],
    [ "p_char_pf", "a00237.html#af7a06b2899457e00a555432106cc21f2", null ],
    [ "p_char_user_desc", "a00237.html#a6d3f8e028fac8cba3158281ec6880118", null ],
    [ "p_sccd_md", "a00237.html#a859f6ec1fc35c5983fc34a09c79b8b1e", null ],
    [ "p_user_desc_md", "a00237.html#ae4858815d704c68d78b4a318011252b6", null ]
];