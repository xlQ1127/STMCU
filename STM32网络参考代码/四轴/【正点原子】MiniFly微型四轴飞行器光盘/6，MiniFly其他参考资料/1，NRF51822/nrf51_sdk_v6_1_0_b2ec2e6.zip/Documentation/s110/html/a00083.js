var a00083 =
[
    [ "Architecture", "a00083.html#nrf51_arch_serialization", null ],
    [ "Serialization Setup", "a00085.html", null ],
    [ "BLE S110 Connectivity Chip", "a00084.html", null ],
    [ "BLE Serialization Codecs", "a00086.html", "a00086" ],
    [ "Serialization PHY", "a00103.html", "a00103" ],
    [ "Serialization HAL Transport", "a00104.html", null ]
];