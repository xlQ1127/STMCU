var a00229 =
[
    [ "handle", "a00229.html#af1b50c1fd1d5be05d0d0cf25e0925fd0", null ],
    [ "p_value", "a00229.html#a6e842e1c975c50acf7eec947baa405e8", null ]
];