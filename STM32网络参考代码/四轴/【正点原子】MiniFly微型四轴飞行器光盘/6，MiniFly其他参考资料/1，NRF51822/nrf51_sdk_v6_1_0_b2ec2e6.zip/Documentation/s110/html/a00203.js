var a00203 =
[
    [ "conn_handle", "a00203.html#a2c0b8fc1f46e4360b34a1806061e828a", null ],
    [ "p_actual_latency", "a00203.html#a769493b896a8e6709956d5248aaa94d6", null ],
    [ "requested_latency", "a00203.html#ac06a0a4e53f12763e0966c9bff3e0545", null ]
];