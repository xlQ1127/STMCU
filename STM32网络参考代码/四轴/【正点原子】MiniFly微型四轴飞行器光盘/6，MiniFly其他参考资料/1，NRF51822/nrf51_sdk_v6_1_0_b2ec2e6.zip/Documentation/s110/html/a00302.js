var a00302 =
[
    [ "service_handle", "a00302.html#a4ebaa77023ad95d4ea1bb2a046b9ea80", null ],
    [ "tx_power_level_handles", "a00302.html#a6b43774912f600a0069a22603c69bc48", null ]
];