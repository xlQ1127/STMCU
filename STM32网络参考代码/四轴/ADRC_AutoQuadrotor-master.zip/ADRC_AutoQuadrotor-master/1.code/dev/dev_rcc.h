#ifndef DEV_RCC_H
#define DEV_RCC_H
#include "includes.h"
class _RCC
{
	 private:
	 public:	
	 static void Configuration(void);
	
};
extern _RCC   Rcc;

#endif