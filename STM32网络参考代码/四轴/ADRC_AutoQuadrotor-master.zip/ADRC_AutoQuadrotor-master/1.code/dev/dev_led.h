#ifndef DEV_LED_H
#define DEV_LED_H
#include "includes.h"
class _LED
{
	private:
		
	public:
	void Configuration(void);
	

};

extern _LED Led;



#endif