var a00284 =
[
    [ "error_handler", "a00284.html#ad807ea2ae006260b7c63872abc7961a9", null ],
    [ "evt_handler", "a00284.html#aba9fc4fcd56873873aa82aace5c804f7", null ],
    [ "initial_alert_level", "a00284.html#a7e1cfca38578d65b9e40d1dffd69ebf6", null ],
    [ "lls_attr_md", "a00284.html#a4107eb4f75941f56faea5db0b273c863", null ]
];