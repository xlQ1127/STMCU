var a00276 =
[
    [ "alert_level_handle", "a00868.html#gad136ca554bce057fd4cd38ba0f796ea6", null ],
    [ "conn_handle", "a00868.html#gad18ae38bccb88d086eedbc1647ce2386", null ],
    [ "error_handler", "a00868.html#ga6cecf3d78ec7d72912dd4215455720ed", null ],
    [ "evt_handler", "a00868.html#gac306d48fcd140ddbffb4d4c64ca4d007", null ]
];