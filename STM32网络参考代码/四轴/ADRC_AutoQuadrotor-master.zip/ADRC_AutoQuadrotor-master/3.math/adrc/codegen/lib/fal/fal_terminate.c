/*
 * File: fal_terminate.c
 *
 * MATLAB Coder version            : 2.6
 * C/C++ source code generated on  : 28-Jun-2017 11:24:40
 */

/* Include files */
#include "rt_nonfinite.h"
#include "fal.h"
#include "fhan.h"
#include "fal_terminate.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void fal_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for fal_terminate.c
 *
 * [EOF]
 */
