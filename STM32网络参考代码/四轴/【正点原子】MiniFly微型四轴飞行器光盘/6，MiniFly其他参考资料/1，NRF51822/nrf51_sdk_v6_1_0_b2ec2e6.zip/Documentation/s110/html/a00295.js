var a00295 =
[
    [ "conn_handle", "a00295.html#a521616c53ae38b73795cca328521ef42", null ],
    [ "error_handler", "a00295.html#aaec55bf5a1343f070d446923693e5f12", null ],
    [ "evt_handler", "a00295.html#ac210b0c8592add4d7affa83d70b3df08", null ],
    [ "list_supported_locations", "a00295.html#a7e935a23cddf974b27ea97ae274eeac1", null ],
    [ "procedure_status", "a00295.html#a785beee8dcd8f49f18b408337791e397", null ],
    [ "response", "a00295.html#a706cd93a550c24bee3c5adfb6c0c9c5e", null ],
    [ "sc_ctrlpt_handles", "a00295.html#acac883600df15bd18d45f56c7d859b6a", null ],
    [ "sensor_location_handle", "a00295.html#a911a8cc3010ade3dc33e90a4cf907e4d", null ],
    [ "service_handle", "a00295.html#a638b4208c1e4a00d43b955a43553b4ed", null ],
    [ "size_list_supported_locations", "a00295.html#adb0d88b6ef155271629eeed8db295422", null ],
    [ "supported_functions", "a00295.html#a258978b06152814aa7fb2bad9c3e4691", null ]
];