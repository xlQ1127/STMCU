var a00223 =
[
    [ "data", "a00223.html#adaf3ed862b2c96947da60d9b576b31c9", null ],
    [ "handle", "a00223.html#a54644f05780b15248eba975decdd4e48", null ],
    [ "len", "a00223.html#a5131e80ad4da52f707a84aed7240f2ee", null ],
    [ "offset", "a00223.html#a1ed66c83e153fd6471056d19b10fac67", null ]
];