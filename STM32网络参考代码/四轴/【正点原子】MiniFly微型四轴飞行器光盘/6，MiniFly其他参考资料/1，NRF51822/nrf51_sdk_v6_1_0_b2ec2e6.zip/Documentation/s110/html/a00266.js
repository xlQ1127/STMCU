var a00266 =
[
    [ "boot_kb_inp_rep_handles", "a00266.html#aa31e87ba295f282b70a98222cc2d3fcc", null ],
    [ "boot_kb_outp_rep_handles", "a00266.html#a8c8d5455ff6ec5854f5b0fe3e38f722c", null ],
    [ "boot_mouse_inp_rep_handles", "a00266.html#a8b115742e76add897fb332cb77bf081a", null ],
    [ "conn_handle", "a00266.html#aeca3d69373de621e4ca332bf6b5984bd", null ],
    [ "error_handler", "a00266.html#aad5b627e9fa39362dc586d9f5a18b886", null ],
    [ "evt_handler", "a00266.html#af14cb4fcfb90428bef5dde26f2dbbc8c", null ],
    [ "feature_rep_array", "a00266.html#a4cdbd7dea57702309ba6fabda04b92b3", null ],
    [ "feature_rep_count", "a00266.html#a3f1837c205c62ff0a2f5938467eb9116", null ],
    [ "hid_control_point_handles", "a00266.html#a033e6876ba6f549ef2ba199c90ce3199", null ],
    [ "hid_information_handles", "a00266.html#ad873bd754571a42ee367c2f85448efac", null ],
    [ "inp_rep_array", "a00266.html#a0b2f9ea0ae58be58ff1b12bd72600ae9", null ],
    [ "inp_rep_count", "a00266.html#a414d074d9bcf9405bbc9de8e404a8f11", null ],
    [ "outp_rep_array", "a00266.html#a2b24228b1fd9372646dad4ef392a8fe7", null ],
    [ "outp_rep_count", "a00266.html#aea5350a28091b83e3b992fb273b1829a", null ],
    [ "protocol_mode_handles", "a00266.html#a4dda3a819ae7bc7b3b4b4f91db642f5c", null ],
    [ "rep_map_ext_rep_ref_handle", "a00266.html#af98acb1f2b53d554f1652825e2e57661", null ],
    [ "rep_map_handles", "a00266.html#a6121cb2fc16664059745f58549c95763", null ],
    [ "service_handle", "a00266.html#a5e292df7c129413e237e917afbe8f2b5", null ]
];