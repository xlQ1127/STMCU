var a00307 =
[
    [ "id_info", "a00307.html#a46a8d2c66a3a8eb114173e6f88163fd9", null ],
    [ "irk", "a00307.html#a07fd1fbebc7504dd56072f310510ff7d", null ]
];