var a00271 =
[
    [ "evt_handler", "a00271.html#ac6fbae8371e9336d3acb46b8903a8947", null ],
    [ "hts_meas_attr_md", "a00271.html#a5c4a4bc737442da34f2b9cfd367bb5e8", null ],
    [ "hts_temp_type_attr_md", "a00271.html#a1f216c81224e94f40db0d5b4aaa1898b", null ],
    [ "temp_type", "a00271.html#a7d233be4574d7bdd2f28c9afa8d0efc2", null ],
    [ "temp_type_as_characteristic", "a00271.html#a6ac11fedc2f4a022e482c6342880e30f", null ]
];