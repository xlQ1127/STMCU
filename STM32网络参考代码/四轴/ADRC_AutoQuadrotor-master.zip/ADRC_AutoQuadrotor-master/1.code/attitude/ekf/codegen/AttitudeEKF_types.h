/* 
 * File: AttitudeEKF_types.h 
 *  
 * MATLAB Coder version            : 2.6 
 * C/C++ source code generated on  : 23-Apr-2017 01:32:45 
 */

#ifndef __ATTITUDEEKF_TYPES_H__
#define __ATTITUDEEKF_TYPES_H__

/* Include files */
#include "rtwtypes.h"

#endif
/* 
 * File trailer for AttitudeEKF_types.h 
 *  
 * [EOF] 
 */
