#ifndef DEV_CAN_H
#define DEV_CAN_H
#include "stm32f4xx.h"

class _CAN
{
	private:
	public:

};


#endif