var a00263 =
[
    [ "max_len", "a00263.html#ac0cfa5494f231413123e5f9b18356591", null ],
    [ "read_resp", "a00263.html#a9928aad36b7acb9a2d9202384b8d058e", null ],
    [ "rep_ref", "a00263.html#a75349cbfb49b717b2fda5f70b2622775", null ],
    [ "security_mode", "a00263.html#ac658edb5d68d2b14843f1d8274a48f60", null ]
];