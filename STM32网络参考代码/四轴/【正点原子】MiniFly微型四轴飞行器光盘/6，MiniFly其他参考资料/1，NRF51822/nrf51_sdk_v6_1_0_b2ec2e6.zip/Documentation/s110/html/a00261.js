var a00261 =
[
    [ "error_handler", "a00261.html#a348bc87e17753e1606fa2f69776fc812", null ],
    [ "evt_handler", "a00261.html#ac556d1dd9fc887e0a4b9f09d07c55334", null ],
    [ "feature_rep_count", "a00261.html#ad300d14d2242b2d62fce14bb6f5b22d9", null ],
    [ "hid_information", "a00261.html#abd10367fccd9ed2769f53fd48a53edae", null ],
    [ "included_services_count", "a00261.html#aa5d9b0a338623e121645bd5f1c95b447", null ],
    [ "inp_rep_count", "a00261.html#a49bc68d03c380079324253f2814b0d8b", null ],
    [ "is_kb", "a00261.html#aa6c5ebde3de8b7e2ce3a875fe5e4677e", null ],
    [ "is_mouse", "a00261.html#ace2e84fb6d3caeb8005c30019ba5da01", null ],
    [ "outp_rep_count", "a00261.html#aaef06614621108b1cbcf899dd049ca1f", null ],
    [ "p_feature_rep_array", "a00261.html#abb18c2ab0ca4201cdbc4bc24892ffba0", null ],
    [ "p_included_services_array", "a00261.html#a9e5826891cda3e96702e53cfb382c419", null ],
    [ "p_inp_rep_array", "a00261.html#aabed7d34793cf270bb665237975c0e1a", null ],
    [ "p_outp_rep_array", "a00261.html#ab2e8ef802d1179e3adf99a8a985916a3", null ],
    [ "rep_map", "a00261.html#ab6c5e4e298cf612f986069d0b76d6fca", null ],
    [ "security_mode_boot_kb_inp_rep", "a00261.html#a2946d2c8678418813ce84d3a2d59e0b2", null ],
    [ "security_mode_boot_kb_outp_rep", "a00261.html#a2838fb8e4efceeb941245155f469fa0e", null ],
    [ "security_mode_boot_mouse_inp_rep", "a00261.html#a082e9a087723dd62d352847296672302", null ],
    [ "security_mode_ctrl_point", "a00261.html#a4113e6621315caa0b2a95e35d1863a33", null ],
    [ "security_mode_protocol", "a00261.html#aa5933daad55ab978998cdcdf9757c0cf", null ]
];