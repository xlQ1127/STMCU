var a00002 =
[
    [ "UART", "a00008.html", null ],
    [ "TWI", "a00007.html", null ],
    [ "SPI Master", "a00006.html", [
      [ "SPI Module Initialization and Configuration", "a00006.html#spi_master_init", null ],
      [ "SPI Master Data Exchange API", "a00006.html#spi_master_send_recv", null ]
    ] ]
];