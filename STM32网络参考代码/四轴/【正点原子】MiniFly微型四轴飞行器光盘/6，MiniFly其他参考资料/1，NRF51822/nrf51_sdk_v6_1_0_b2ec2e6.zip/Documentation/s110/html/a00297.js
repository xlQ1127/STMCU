var a00297 =
[
    [ "cccd_write_perm", "a00297.html#a320070d4ad9b4f4948a8bba65f3853c0", null ],
    [ "read_perm", "a00297.html#ab3203f11dcbf8bea6cbe1dcffbf68661", null ],
    [ "write_perm", "a00297.html#ac8a8cd605d17911a751bf74d72412568", null ]
];