#ifndef CONTROL_H
#define CONTROL_H
#include "stm32f4xx.h"
class CONTROL_
{
	public:
	void V(void);
	float u;
	float wight;

};


extern CONTROL_ ctrl;

#endif