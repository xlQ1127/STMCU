var a00206 =
[
    [ "local_conn_latency", "a00206.html#a1bb53c22c985681a03ee48b81498112c", null ],
    [ "passkey", "a00206.html#ada41fdfa545113ec48371bc74ec7aa9a", null ],
    [ "privacy", "a00206.html#a19819de8fc2357584b987c5087f2c54a", null ]
];