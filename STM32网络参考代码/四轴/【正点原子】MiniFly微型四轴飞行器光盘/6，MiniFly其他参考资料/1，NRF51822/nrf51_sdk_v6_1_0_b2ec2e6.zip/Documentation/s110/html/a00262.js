var a00262 =
[
    [ "max_len", "a00262.html#a656fc246bd9f18026083e3efb640052e", null ],
    [ "read_resp", "a00262.html#a49208f982abf135a1f8d5c76ee893995", null ],
    [ "rep_ref", "a00262.html#aeb77c0bc0738fbb0be766e574ac173b5", null ],
    [ "security_mode", "a00262.html#a757afd0e411e7e67224c94fefcf26bab", null ]
];