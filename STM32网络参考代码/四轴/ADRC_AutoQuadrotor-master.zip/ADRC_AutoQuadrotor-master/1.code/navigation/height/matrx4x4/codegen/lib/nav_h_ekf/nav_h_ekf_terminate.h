/*
 * File: nav_h_ekf_terminate.h
 *
 * MATLAB Coder version            : 2.6
 * C/C++ source code generated on  : 03-Jul-2017 10:29:44
 */

#ifndef __NAV_H_EKF_TERMINATE_H__
#define __NAV_H_EKF_TERMINATE_H__

/* Include files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "nav_h_ekf_types.h"

/* Function Declarations */
extern void nav_h_ekf_terminate(void);

#endif

/*
 * File trailer for nav_h_ekf_terminate.h
 *
 * [EOF]
 */
