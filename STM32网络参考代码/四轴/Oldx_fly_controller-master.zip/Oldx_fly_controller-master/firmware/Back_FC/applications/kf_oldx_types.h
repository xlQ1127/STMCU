/* 
 * File: kf_oldx_types.h 
 *  
 * MATLAB Coder version            : 2.7 
 * C/C++ source code generated on  : 26-Nov-2016 14:12:33 
 */

#ifndef __KF_OLDX_TYPES_H__
#define __KF_OLDX_TYPES_H__

/* Include Files */ 
#include "rtwtypes.h"

#endif
/* 
 * File trailer for kf_oldx_types.h 
 *  
 * [EOF] 
 */
