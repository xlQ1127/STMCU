/*
 * File: fal.h
 *
 * MATLAB Coder version            : 2.6
 * C/C++ source code generated on  : 28-Jun-2017 11:24:40
 */

#ifndef __FAL_H__
#define __FAL_H__

/* Include files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "fal_types.h"

/* Function Declarations */
extern float fal(float e, float a, float d);

#endif

/*
 * File trailer for fal.h
 *
 * [EOF]
 */
