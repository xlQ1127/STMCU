var a00171 =
[
    [ "conn_handle", "a00171.html#a48a44e4e8cd1e67fbb32989de8a99b36", null ],
    [ "dfu_ctrl_pt_handles", "a00171.html#a2b5f5316143335f6f2b8a41058097d17", null ],
    [ "dfu_pkt_handles", "a00171.html#a759fe67aab5aa380ef2fb004b162fd7d", null ],
    [ "dfu_status_rep_handles", "a00171.html#a458dbd2ff5429f61da7adb60e0905ba8", null ],
    [ "error_handler", "a00171.html#a49fa8cfd9bce660ff46708670a6b0eef", null ],
    [ "evt_handler", "a00171.html#a306430130c5f0868b715478449009be0", null ],
    [ "service_handle", "a00171.html#abac31261d78df5dfec65e37ba3d456fb", null ],
    [ "uuid_type", "a00171.html#a8e4c2d2d6901dc489294370ecff5632b", null ]
];