/* 
 * File: KF_OLDX_NAV_types.h 
 *  
 * MATLAB Coder version            : 2.7 
 * C/C++ source code generated on  : 03-Dec-2016 20:26:50 
 */

#ifndef __KF_OLDX_NAV_TYPES_H__
#define __KF_OLDX_NAV_TYPES_H__

/* Include Files */ 
#include "rtwtypes.h"

#endif
/* 
 * File trailer for KF_OLDX_NAV_types.h 
 *  
 * [EOF] 
 */
