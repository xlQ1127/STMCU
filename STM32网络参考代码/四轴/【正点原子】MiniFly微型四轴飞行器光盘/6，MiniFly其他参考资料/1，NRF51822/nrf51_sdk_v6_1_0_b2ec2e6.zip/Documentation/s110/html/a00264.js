var a00264 =
[
    [ "char_handles", "a00264.html#a3f137cc3f92bf439d93a8491e4314d5a", null ],
    [ "ref_handle", "a00264.html#a0209468bba2c298192f4500a652dd6d1", null ]
];