var a00283 =
[
    [ "alert_level", "a00283.html#adaf4d087319007c776df8baf3673fe8a", null ],
    [ "evt_type", "a00283.html#a971a9cd94583dae76dcf5f94eb412686", null ],
    [ "params", "a00283.html#a8e6dbb58fa8b034ea23257bcc2785954", null ]
];