var a00103 =
[
    [ "SPI RAW protocol", "a00098.html", [
      [ "SPI RAW protocol", "a00098.html#SPI_RAW_PROTOCOL", null ],
      [ "SPI RAW - packet writing", "a00098.html#SPI_RAW_BUS_TX", null ],
      [ "SPI RAW - packet reading", "a00098.html#SPI_RAW_BUS_RX", null ],
      [ "Master device driver", "a00098.html#SPI_RAW_DRIVER_MASTER", null ],
      [ "Slave device driver", "a00098.html#SPI_RAW_DRIVER_SLAVE", null ]
    ] ],
    [ "SPI_5W RAW protocol", "a00099.html", [
      [ "SPI_5W RAW Protocol", "a00099.html#SPI_5W_RAW_PROTOCOL", null ],
      [ "SPI_5W RAW - packet writing", "a00099.html#SPI_5W_RAW_BUS_TX", null ],
      [ "SPI_5W RAW packet reading", "a00099.html#SPI_5W_RAW_BUS_RX", null ],
      [ "master device driver", "a00099.html#SPI_5W_RAW_DRIVER_MASTER", null ],
      [ "slave device driver", "a00099.html#SPI_5W_RAW_DRIVER_SLAVE", null ]
    ] ],
    [ "UART RAW protocol", "a00100.html", [
      [ "UART RAW protocol", "a00100.html#UART_RAW_PROTOCOL", null ],
      [ "UART RAW packet", "a00100.html#UART_RAW_PACKET", null ],
      [ "UART driver", "a00100.html#UART_RAW_DRIVER", null ]
    ] ],
    [ "UART HCI protocol", "a00101.html", [
      [ "UART HCI protocol", "a00101.html#UART_HCI_PROTOCOL1", null ],
      [ "HCI LAYER", "a00101.html#UART_HCI_PROTOCOL2", null ],
      [ "SLIP LAYER", "a00101.html#UART_HCI_PROTOCOL3", null ],
      [ "UART HCI SLIP packet", "a00101.html#UART_HCI_SLIP_PACKET", null ],
      [ "UART HCI SLIP driver", "a00101.html#UART_HCI_SLIP_DRIVER", null ]
    ] ],
    [ "UART STM RAW protocol", "a00102.html", [
      [ "UART STM RAW protocol", "a00102.html#UART_STM", null ]
    ] ]
];