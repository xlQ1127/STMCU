var a00161 =
[
    [ "conn_handle", "a00161.html#acb6ea6f96806c80017f6d80a65fa1c40", null ],
    [ "evt_handler", "a00161.html#ad503c598af64ae0973fcbd69c2564f6c", null ],
    [ "feature", "a00161.html#ab6a6c9882bfb4ca35a22b2b46e6cc342", null ],
    [ "feature_handles", "a00161.html#ad7b6cace6c499b77b40be59b7d9ed843", null ],
    [ "meas_handles", "a00161.html#ab61b1c5af5765ac4f24f617a24a81cd0", null ],
    [ "service_handle", "a00161.html#a08ca745c921f74e622b3226b74a5453a", null ]
];