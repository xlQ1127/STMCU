var a00292 =
[
    [ "cumulative_value", "a00292.html#ad226d0754bf0b129e4202d6468918de8", null ],
    [ "evt_type", "a00292.html#a4ae317b0ff9170a27f7315dfb3c12bb6", null ],
    [ "params", "a00292.html#aa9b38db69e5c8e140630cf82bff0d595", null ],
    [ "update_location", "a00292.html#a64e560612783b28ce208966239c7ec07", null ]
];