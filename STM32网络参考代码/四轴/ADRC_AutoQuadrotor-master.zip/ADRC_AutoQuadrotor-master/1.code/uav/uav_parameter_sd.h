#ifndef UAV_PARAMETER_SD_H
#define UAV_PARAMETER_SD_H

class PARAMETER_SD
	{
	public:
	void SaveDataInit(void);

};


extern PARAMETER_SD parameter_sd;






















#endif