/* 
 * File: nav_h_ekf_types.h 
 *  
 * MATLAB Coder version            : 2.6 
 * C/C++ source code generated on  : 03-Jul-2017 02:29:18 
 */

#ifndef __NAV_H_EKF_TYPES_H__
#define __NAV_H_EKF_TYPES_H__

/* Include files */
#include "rtwtypes.h"

#endif
/* 
 * File trailer for nav_h_ekf_types.h 
 *  
 * [EOF] 
 */
